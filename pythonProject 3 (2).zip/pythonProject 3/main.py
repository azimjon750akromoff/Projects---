from flask import Flask, render_template, request, flash, redirect, url_for, session
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash, check_password_hash
from passlib.hash import scrypt

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = "sqlite:///User.db"
app.config['SECRET_KEY'] = 'secret'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db = SQLAlchemy(app)


# Define your User model
class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(100), unique=True, nullable=False)
    email = db.Column(db.String(100), unique=True, nullable=False)
    password_hash = db.Column(db.String(400), nullable=False)

    def __init__(self, username, email, password):
        self.username = username
        self.email = email
        self.password_hash = generate_password_hash(password)


# Route to handle adding items to the cart
@app.route('/add_to_cart/<item_id>')
def add_to_cart(item_id):
    # Initialize the cart in the session if it doesn't exist
    if 'cart' not in session:
        session['cart'] = []

    # Add the item to the cart
    session['cart'].append(item_id)

    flash('Item added to cart successfully!')
    return redirect(url_for('index1'))  # Redirect to the store page or wherever appropriate


@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        if not username or not password:
            flash('Username and password are required.')
            return render_template('login.html')

        users = User.query.filter_by(username=username).first()
        if users:
            if check_password_hash(users.password_hash, password):
                session['username'] = username
                flash('Logged in successfully!')
                return redirect(url_for('index1'))  # Redirect to the store page or wherever appropriate
            else:
                error = 'Invalid username or password. Please try again.'
                return render_template('login.html', error=error)
        else:
            error = 'User not found. Please register.'
            return render_template('login.html', error=error)

    return render_template('login.html')


@app.route('/', methods=['GET', 'POST'])
def index():
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        if not username or not password:
            flash('Username and password are required.')
            return render_template('home.html')

        user = User.query.filter_by(username=username).first()
        if user:
            if check_password_hash(user.password_hash, password):
                session['username'] = username
                flash('Logged in successfully!')
                return redirect(url_for('index1'))
            else:
                error = 'Invalid username or password. Please try again.'
                return render_template('home.html', error=error)
        else:
            error = 'User not found. Please register.'
            return render_template('home.html', error=error)
    return render_template('login.html')


@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        session.permanent = True
        username = request.form['username']
        session['username'] = username
        email = request.form.get('email', '')
        password = request.form['password']

        if not username or not password:
            error = 'Username and password are required.'
            return render_template('register.html', error=error)
        found_user = User.query.filter_by(username=username).first()
        if found_user:
            session["email"] = found_user.email
        else:
            usr = User(username=username, email=email, password=password)
            db.session.add(usr)
            db.session.commit()
        return redirect(url_for('index1'))
    return render_template('register.html')


@app.route('/about')
def about():
    return render_template('about.html')

@app.route('/privacy')
def privacy():
    return render_template('privacy.html')

@app.route('/policy')
def policy():
    return render_template('policy.html')

@app.route('/contact_us')
def contact():
    return render_template('contact_us.html')

@app.route('/storepage')
def index1():
    return render_template('home.html')

@app.route('/cart')
def cart():
    return render_template('cart.html')


if __name__ == '__main__':
    with app.app_context():
        db.create_all()
    app.run(debug=True)